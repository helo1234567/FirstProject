package SteP_Ddefinition;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.testng.Assert.assertEquals;

import org.testng.annotations.Test;



import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

import io.cucumber.java.BeforeAll;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;



public class Steps__definition {
	

	static WebDriver driver=new FirefoxDriver();
	//static WebDriver driver=new ChromeDriver();
	
	All__Methods object =new All__Methods(driver);
	
	@BeforeTest
	@BeforeAll
	public static void before() {
//		 ChromeOptions chromeOptions = new ChromeOptions();
//		 chromeOptions.addArguments("--remote-allow-origins=*");
//		 ChromeDriver driver = new ChromeDriver(chromeOptions);
//		 System.setProperty("webdriver.http.factory", "jdk-http-client");
		 //System.setProperty("webdriver.chrome.driver","C:\\Users\\Hassan\\Desktop\\chromedriver_win32 (3)\\chromedriver.exe");
		 System.setProperty("webdriver.gecko.driver","C:\\Users\\DELL\\Downloads\\geckodriver-v0.33.0-win32\\geckodriver.exe");
		 driver.get("https://www.spectrum.com/");
		 driver.manage().window().maximize();
	}
	
	
	@Test(priority=0)
	@Given("User is on Home page of Spectrum.com")
	public void Home_page() {
		System.out.println("asad");
		
	}
	
	@Test(priority=1)
	@When("User Hover over on Mobile Tab and select Spectrum Mobile from dropdown")
	public void User_Hover_over_on_Mobile_Tab_and_select_Spectrum_Mobile_from_dropdown() {
		
		object.explore_Mobiletab();
	    
	}
	
	
	@Test(priority=2)
	@Then("Verify that the URL of page will be {string}")
	public void Verify_that_the_title_of_the_page(String HomeURL) {
		String actual_Title=driver.getCurrentUrl();
		assertEquals(HomeURL,actual_Title);
		
	    
	}
	
	@Test(priority=3)
	@When("User Hover over on Products Tab & select Phones from dropdown")
	public void User_Hover_over_on_Plans_Tab_select_Mobile_Data_Plan_from_dropdown() throws InterruptedException {
	
		object.select_Mobile();
	    
	}

	@Test(priority=4)
	@Then("Verify that the URL of the page should be {string}")
	public void Verify_that_the_URL_of_the_page(String pageURL) {
		String actual_URL=driver.getCurrentUrl();
		assertEquals(pageURL,actual_URL);
	
	}
	
	@Test(priority=5)
	@When("User clicks on Apple Tab")
	public void Shop_Now() throws InterruptedException {
	
		object.Select_Cellphones();
	    
	}
	
	@Test(priority=6)
	@And("Select Iphone 14 promax of Apple Brand")
	public void Select_Cellphone() throws InterruptedException {
		System.out.println("asad");
		
	}
	

	@Test(priority=7)
	@Then("Verify that the title of the page will be {string}")
	public void Navigate_To_given_URL(String Iphone14_pagetile){
		String actual_Title=driver.getTitle();
		assertEquals(Iphone14_pagetile,actual_Title);
		
	}
	
	@Test(priority=8)
	@When("User Select specifications like\\(color,storage) of cellphone")
	public void Select_specification() throws InterruptedException {
	
		object.Select_specifications();
	    
	}
	
	@Test(priority=9)
	@And("Put information of Trade_In & click on Continue buton")
	public void Trade_IN() throws InterruptedException {
	
		object.Enter_Trade_In_Informtion();
	    
	}
	
	@Test(priority=10)
	@Then("Verify that the URL of the page must be {string}")
	public void Verify_URL_of_the_page(String pageURL) {
		String actual_URL=driver.getCurrentUrl();
		assertEquals(pageURL,actual_URL);
	
	}
	
	
	@Test(priority=11)
	@When("User clicks on No,Shop Internet")
	public void No_Shop_Internet() throws InterruptedException {
	
		object.No_Shop_Internet();
	    
	}
	
	@Test(priority=12)
	@And("Clicks on Order Now")
	public void Order_Now() throws InterruptedException {
	
		object.Click_OrderNow();
	    
	}
	
	@Test(priority=13)
	@Then("User must navigate to URL {string}")
	public void Checking_URL(String AddressPageURL) throws InterruptedException {
		String actual_URL=driver.getCurrentUrl();
		assertEquals(AddressPageURL,actual_URL);
		
	}
	
	@Test(priority=14)
	@When("^User enters (.*) and (.*) and click on login$")
	public void Enter_LoginDetails(String username,String password) throws InterruptedException {
	
		object.Enter_Login_details(username,password);
	    
	}
	
	@Test(priority=15)
	@Then("{string} message will apear on screen")
	public void Checking_message(String unsuccesfullString_message) throws InterruptedException {
		String actualmesage=object.Get_text();
		assertEquals(unsuccesfullString_message,actualmesage);
		
	}
	
	@Test(priority=16)
	@When("^enters (.*) and (.*) and enter address details$")
	public void user_fills_form_from_given_sheetname_sheet_name_and_rownumber(String SheetName,Integer RowNumber) throws InvalidFormatException, IOException, InterruptedException {
	   ExcelReader reader=new ExcelReader();
	   List<Map<String,String>> testData=reader.getData("C:\\Users\\Hassan\\Desktop\\contactdetails.xlsx", SheetName);
	   String adres=testData.get(RowNumber).get("Adrees"); 
	   String apat =testData.get(RowNumber).get("Apprt"); 
	   String zipcde=testData.get(RowNumber).get("Zipcode"); 
	   String mes=testData.get(RowNumber).get("message"); 
	   object.Enter_address(adres, apat, zipcde, mes);
	   
	}
	@Test(priority=17)
	@Then("it shows successfull message {string}")
	public void it_shows_successfull_message(String string)   {
		String actualmessage=object.getext();
		assertEquals(actualmessage,string);
	    
	}
	
	
}
