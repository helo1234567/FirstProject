package SteP_Ddefinition;

import org.junit.runner.RunWith;
import org.testng.annotations.Test;

import io.cucumber.junit.CucumberOptions;
import io.cucumber.junit.Cucumber;
@Test
@RunWith(Cucumber.class)
@CucumberOptions(features="src/test/resources/Featuress",glue={"SteP_Ddefinition"},monochrome=true,

plugin = {"json:target/cucumber.json"}
)

public class Testrunner {

	
}
