package sampleprojectHelo;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;


public class heoone {
	
WebDriver driver;
	
	
	@FindBy(xpath="//a[@role='button' and @title='Mobile']")
	WebElement Hover_Mobile_Tab;
	
	@FindBy(xpath="//a[@role='button' and @title='Internet']")
	WebElement Hover_Internet_Tab;
	
	@FindBy(xpath="(//a[contains(text(),'Spectrum Mobile')])[1]")
	WebElement click_spectrum_Mobile;
	
	@FindBy(xpath="//div[@class='spectrum-logo-container false']")
	static
	WebElement Spectrum_mobile_logo;
	
	@FindBy(xpath="//a[@id='collapsible-nav-dropdown-1']")
	WebElement Hover_over_product;
	
	@FindBy(xpath="//a[@class='dropdown-item' and @data-linkname='Phones']")
	WebElement Select_phones;
	
	@FindBy(xpath="//h1[contains(text(),'Shop the Newest Smartphones')]")
	WebElement shop_newest_phones;
	
	@FindBy(xpath="//a[@id='button-3c1e52eb88']")
	WebElement shop_now;
	
	@FindBy(xpath="//li[@id='APL']")
	WebElement iphone_tab;
	
	@FindBy(xpath="//h1[contains(text(),'Shop New Apple iPhones')]")
	WebElement iphone_apple_des;
	
	@FindBy(xpath="//img[@alt='Apple iPhone 14 Pro Max Deep Purple']")
	WebElement iphone_14_promax;
	
	@FindBy(xpath="//button[@class='variant-circle gold false' and @title='Gold']")
	WebElement select_iphone_colcor;
	
	@FindBy(xpath="//span[contains(text(),'256 GB')]")
	WebElement select_storage;
	
	@FindBy(xpath="//li[@aria-label='slide item 2']")
	WebElement choose_second_picture;
	
	@FindBy(xpath="//span[contains(text(),'when it ships')]")
	WebElement when_ship;
	
	@FindBy(xpath="//span[contains(text(),'$15/mo plus tax, if applicable')]")
	WebElement protection_plan;
	
	@FindBy(xpath="//button[contains(text(),'Add Trade-In')]")
	WebElement Add_TradeIn;
	
	@FindBy(xpath="//div[contains(text(),'Trade-In')]")
	WebElement TradeIn_logo;
	
	@FindBy(xpath="//img[@alt='ATT']")
	WebElement select_ATT;
	
	@FindBy(xpath="//img[@alt='Apple']")
	WebElement select_apple;
	
	@FindBy(xpath="//input[@id='modelAutoComplete']")
	WebElement inputfield;
	
	@FindBy(xpath="//li[contains(text(),'IPAD 10 10.9')]")
	WebElement select_fromdropdown;
	
	@FindBy(xpath="//button[contains(text(),'256GB')]")
	WebElement storage;
	
	@FindBy(xpath="//button[contains(text(),'CONTINUE')]")
	WebElement click_continue;
	
	@FindBy(xpath="//input[@name='imeiNumber']")
	WebElement imei_Number;
	
	@FindBy(xpath="//input[@name='DAM_FREE_CTI' and @value='DAMF_YES']")
	WebElement click_yes;
	
	@FindBy(xpath="//input[@name='LCD_GOOD_CTI' and @value='LCDG_YES']")
	WebElement second_yes;
	
	@FindBy(xpath="//input[@name='NO_LIQUID_CTI' and @value='NOLIQ_NO']")
	WebElement first_No;
	
	@FindBy(xpath="//input[@name='POWER_ON_CTI' and @value='POWER_NO']")
	WebElement second_no;
	
	@FindBy(xpath="//div[contains(text(),'This device is not eligible for Trade-In.')]")
	WebElement message;
	
	@FindBy(xpath="//button[contains(text(),'Cancel')]")
	WebElement cancel;
	
	@FindBy(xpath="//button[text()='NO, SHOP INTERNET']")
	WebElement shop_internet;
	
	@FindBy(xpath="//button[@class='cmp-button' and @data-linktype='orange_button']")
	WebElement order_now1;
	
	
	@FindBy(xpath="//button[@class='show-more']")
	WebElement show_less;
	
	@FindBy(xpath="//input[@name='line1']")
	WebElement enter_address;
	
	@FindBy(xpath="//input[@name='line2']")
	WebElement app_unit;
	
	@FindBy(xpath="//input[@name='postalCode']")
	WebElement zipcode;
	
	@FindBy(xpath="//button[@value='Find Offers']")
	WebElement find_finder;
	
	@FindBy(xpath="//div[contains(text(),'S Park Ave, Fl 26, 10016')]")
	WebElement location;
	
	@FindBy(xpath="//button[text()='YES, SIGN IN']")
	WebElement sign_in;
	
	@FindBy(xpath="//a[contains(text(),'Create a Username')]")
	WebElement create_user;
	
	@FindBy(xpath="//input[@id='contact-info-input']")
	WebElement email_address;
	
	@FindBy(xpath="//input[@id='cc-username']")
	
	WebElement login_email;
	
	@FindBy(xpath="//input[@id='cc-user-password']")
	WebElement login_password;
	
	@FindBy(xpath="//button[@size='lg']")
	WebElement click_signin;
	
	
	@FindBy(xpath="//div[@class='recaptcha-checkbox-border']")
	WebElement recaptcha;
	
	@FindBy(xpath="//button[@class='kite-btn kite-btn-primary kite-btn-lg']")
	WebElement click_next;
	
	@FindBy(xpath="//h3[@class='localization-error__error-text']")
	WebElement large_text;
	
	@FindBy(id="title-bf9fd1c3f8")
	WebElement shop_newphone;
	
	@FindBy(id="title-8679fcab7a")
	WebElement shop_newapplephone;
	
	@FindBy(xpath="//h1[contains(text(),'Are You a Spectrum Customer?')]")
	WebElement pectrumornot;
	
	@FindBy(xpath="//div[@class='ngk-alert-inline-wrapper']")
	WebElement error_message;
	
	@FindBy(xpath="//a[@aria-label='Make appointment for Spectrum store located at 450 W 33rd St']")
	WebElement make_reservation;
	
	public heoone(WebDriver d){
		driver=d;
		PageFactory.initElements(d,this);
}
	

	
	public String getAttribute(WebElement element, String attributeName) {
	    return element.getAttribute(attributeName);
	}
	
	
	public void switchToFrame(WebElement frameElement) {
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(100));
		driver.switchTo().defaultContent();
		wait.until(ExpectedConditions.visibilityOf(frameElement));
	    driver.switchTo().frame(frameElement);
	}
	
	public void switchToTab(int tabIndex) throws InterruptedException {
		
	    ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
	    driver.switchTo().window(tabs.get(tabIndex));
	}
	
	
	

	public Map<String, String> getLocatorData(String locatorName) throws IOException {
	    FileInputStream file = new FileInputStream(new File("./src/test/resources/excel/locators.xlsx"));
	    XSSFWorkbook workbook = new XSSFWorkbook(file);
	    XSSFSheet sheet = workbook.getSheetAt(0);

	    String locatorValue = "";
	    String locatorType = "";
	    for (Row row : sheet) {
	        Cell cell = row.getCell(0);
	        if (cell.getStringCellValue().equals(locatorName)) {
	            locatorValue = row.getCell(1).getStringCellValue();
	            locatorType = row.getCell(2).getStringCellValue(); 
	            break;
	        }
	    }

	    Map<String, String> result = new HashMap<String, String>();
	    result.put("locatorValue", locatorValue);
	    result.put("locatorType", locatorType);
	    return result;
	}

	public void onlyclick(String locatorName) throws IOException {
	    Map<String, String> locatorData = getLocatorData(locatorName);
	    String locatorValue = locatorData.get("locatorValue");
	    String locatorType = locatorData.get("locatorType");
	    driver.findElement(By.xpath(locatorValue)).click();
	}
	
	

}
