package Stepdef_Methods;

import org.junit.runner.RunWith;
import org.testng.annotations.Test;

import io.cucumber.junit.CucumberOptions;
import io.cucumber.junit.Cucumber;
@Test
@RunWith(Cucumber.class)
@CucumberOptions(features="src/test/resources/AllFeatures",glue={"Stepdef_Methods"},monochrome=true,

plugin = { "pretty",
		"html:target/cucumber-html-default",
		"json:target/cucumber-report.json",
		"junit:target/cucumber-report.xml" ,
		"testng:target/cucumber-report.xml"}
)

public class Testrunner {

	
}
