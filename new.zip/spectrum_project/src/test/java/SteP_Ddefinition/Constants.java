package SteP_Ddefinition;

public class Constants {

}
