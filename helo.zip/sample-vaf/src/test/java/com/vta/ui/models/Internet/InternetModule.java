package com.vta.ui.models.Internet;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class InternetModule {
	
	WebDriver driver;

	@FindBy(xpath="//a[@role='button' and @data-linkname='Internet']")
	public
	WebElement Internet_tab;
	
	
	@FindBy(xpath="(//a[contains(text(),'Spectrum Internet')])[1]")
	public
	WebElement click_spectrum_Internet;
	
	@FindBy(xpath="//div[@class='spectrum-logo-container false']")
	public
	WebElement Spectrum_mobile_logo;
	
	@FindBy(xpath="//a[@id='collapsible-nav-dropdown-1']")
	public
	WebElement Hover_over_product;
	
	@FindBy(xpath="//a[@class='dropdown-item' and @data-linkname='Phones']")
	public
	WebElement Select_phones;
	
	@FindBy(xpath="//h1[contains(text(),'Shop the Newest Smartphones')]")
	public
	WebElement shop_newest_phones;
	
	@FindBy(xpath="//a[@id='button-3c1e52eb88']")
	public
	WebElement shop_now;
	
	@FindBy(xpath="//li[@id='APL']")
	public
	WebElement iphone_tab;
	
	@FindBy(xpath="//h1[contains(text(),'Shop New Apple iPhones')]")
	public
	WebElement iphone_apple_des;
	
	@FindBy(xpath="//img[@alt='Apple iPhone 14 Pro Max Deep Purple']")
	public
	WebElement iphone_14_promax;
	
	@FindBy(xpath="//button[@aria-label='Gold' and @title='Gold']")
	public
	WebElement select_iphone_colcor;
	
	@FindBy(xpath="//span[contains(text(),'256 GB')]")
	public
	WebElement select_storage;
	
	@FindBy(xpath="//li[@aria-label='slide item 2']")
	public
	WebElement choose_second_picture;
	
	@FindBy(xpath="//span[contains(text(),'when it ships')]")
	public
	WebElement when_ship;
	
	@FindBy(xpath="//span[contains(text(),'$15/mo plus tax, if applicable')]")
	public
	WebElement protection_plan;
	
	@FindBy(xpath="//button[contains(text(),'Add Trade-In')]")
	public
	WebElement Add_TradeIn;
	
	@FindBy(xpath="//div[contains(text(),'Trade-In')]")
	public
	WebElement TradeIn_logo;
	
	@FindBy(xpath="//img[@alt='ATT']")
	public
	WebElement select_ATT;
	
	@FindBy(xpath="//img[@alt='Apple']")
	public
	WebElement select_apple;
	
	@FindBy(xpath="//input[@id='modelAutoComplete']")
	public
	WebElement inputfield;
	
	@FindBy(xpath="//li[contains(text(),'IPAD 10 10.9')]")
	public
	WebElement select_fromdropdown;
	
	@FindBy(xpath="//button[contains(text(),'256GB')]")
	public
	WebElement storage;
	
	@FindBy(xpath="//button[contains(text(),'CONTINUE')]")
	public
	WebElement click_continue;
	
	@FindBy(xpath="//input[@name='imeiNumber']")
	public
	WebElement imei_Number;
	
	@FindBy(xpath="//input[@name='DAM_FREE_CTI' and @value='DAMF_YES']")
	public
	WebElement click_yes;
	
	@FindBy(xpath="//input[@name='LCD_GOOD_CTI' and @value='LCDG_YES']")
	public
	WebElement second_yes;
	
	@FindBy(xpath="//input[@name='NO_LIQUID_CTI' and @value='NOLIQ_NO']")
	public
	WebElement first_No;
	
	@FindBy(xpath="//input[@name='POWER_ON_CTI' and @value='POWER_NO']")
	public
	WebElement second_no;
	
	@FindBy(xpath="//div[contains(text(),'This device is not eligible for Trade-In.')]")
	public
	WebElement message;
	
	@FindBy(xpath="//button[contains(text(),'Cancel')]")
	public
	WebElement cancel;
	
	@FindBy(xpath="//button[text()='NO, SHOP INTERNET']")
	public
	WebElement shop_internet;
	
	@FindBy(xpath="//button[@class='cmp-button' and @data-linktype='orange_button']")
	public
	WebElement order_now1;
	
	
	@FindBy(xpath="//button[@class='show-more']")
	public
	WebElement show_less;
	
	@FindBy(xpath="//input[@name='line1']")
	public
	WebElement enter_address;
	
	@FindBy(xpath="//input[@name='line2']")
	public
	WebElement app_unit;
	
	@FindBy(xpath="//input[@name='postalCode']")
	public
	WebElement zipcode;
	
	@FindBy(xpath="//button[@value='Find Offers']")
	public
	WebElement find_finder;
	
	@FindBy(xpath="//div[contains(text(),'S Park Ave, Fl 26, 10016')]")
	public
	WebElement location;
	
	@FindBy(xpath="//button[text()='YES, SIGN IN']")
	public
	WebElement sign_in;
	
	@FindBy(xpath="//a[contains(text(),'Create a Username')]")
	public
	WebElement create_user;
	
	@FindBy(xpath="//input[@id='contact-info-input']")
	public
	WebElement email_address;
	
	@FindBy(xpath="//input[@id='cc-username']")
	public
	WebElement login_email;
	
	@FindBy(xpath="//input[@id='cc-user-password']")
	public
	WebElement login_password;
	
	@FindBy(xpath="//button[@size='lg']")
	public
	WebElement click_signin;
	
	@FindBy(xpath="//div[@class='recaptcha-checkbox-border']")
	public
	WebElement recaptcha;
	
	@FindBy(xpath="//button[@class='kite-btn kite-btn-primary kite-btn-lg']")
	public
	WebElement click_next;
	
	@FindBy(xpath="//h3[@class='localization-error__error-text']")
	public
	WebElement large_text;
	
	@FindBy(id="title-bf9fd1c3f8")
	public
	WebElement shop_newphone;
	
	@FindBy(id="title-8679fcab7a")
	public
	WebElement shop_newapplephone;
	
	@FindBy(xpath="//h1[contains(text(),'Are You a Spectrum Customer?')]")
	public
	WebElement pectrumornot;
	
	@FindBy(xpath="//div[@class='ngk-alert-inline-wrapper']")
	public
	WebElement error_message;
	
	@FindBy(xpath="//a[contains(text(),'Motorola')]")
	public
	static
	WebElement motorola_tab;
	
	@FindBy(xpath="//a[contains(text(),'Google')]")
	public
	WebElement Google_tab;
	
	@FindBy(xpath="//a[contains(text(),'Samsung')]")
	public
	WebElement samsung_tab;
	
	@FindBy(xpath="//span[contains(text(),'SHOP ULTRA')]")
	public
	WebElement shop_ultra;
	
	@FindBy(xpath="//button[@id='dropdown-basic-button-sortBy']")
	public
	WebElement dropdown;
	
	@FindBy(xpath="//a[contains(text(),'Price Low-High')]")
	public
	WebElement select_Fromdropdown;
	
	@FindBy(xpath="//a[@id='button-ec38c34bcd']")
	public
	WebElement Get_Offer;
	
	
	
//	@FindBy(xpath="//a[@title='Packages' and @href='/packages' and @class='cmp-navigation__item-link' and @role='button']")
//	public
//	WebElement p;
	
	@FindBy(xpath="/html/body/div[1]/div[3]/div[1]/div/div[1]/div[2]/div[1]/div[1]/div[1]/div/div[1]/div[1]/div/div[1]/div/div/form/button")
	public
	WebElement Find_Offers_button;
	
	@FindBy(xpath="//*[@id=\"SpectrumLogo\"]")
	public
	WebElement verify_address_page;
	
	@FindBy(xpath="(//span[@class='cmp-button__text'])[4]")
	public
	WebElement shop_GIG_Button;
	
	@FindBy(xpath="//*[@id=\"SpectrumLogo\"]")
	public
	WebElement verify_localization_page;
	
	public InternetModule(WebDriver d){
		
		PageFactory.initElements(d,this);
}
}
