package com.vta.ui.steps.internet;

import java.io.IOException;

import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Test;

import com.charter.enumerations.BrowserType;
import com.charter.web.UIManager;
import com.vta.ui.models.Internet.InternetModule;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class InternetSteps {
	UIManager mgr = new UIManager(BrowserType.FF32);
	InternetModule m = new InternetModule(mgr.driver);
	
	@Test(priority=0)
	@When("I navigate {string}")
	public void I_navigate(String url) throws IOException {

	mgr.startSession(url);
	
	
	}
	
	@Test(priority=1)
	@Then("Verify that url of the page must be {string}")
	public void verify_url(String title) throws IOException {
		String actual_url=mgr.getURL();
		UIManager.assertEqual(title, actual_url, "Verify title is matched ");

	}

	@Test(priority=1)
	@Then("Close the Browser")
	public void Browser() throws IOException {
		mgr.endSession();

	}
	@Test(priority=2)
	@Given("User is on Home page of Spectrum.com")
	public void Home_Page() throws IOException {

	System.out.print("spectrum.com");
	
	
	}
	
	@Test(priority=3)
	@When("User Hover over on Internet Tab")
	public void Hover_over() throws IOException {
		
	System.out.print("spectrum.com");
	mgr.waitUntilVisible(m.Internet_tab);
	mgr.hover(m.Internet_tab);
	mgr.waitUntilVisible(m.click_spectrum_Internet);
	}
	
	@Test(priority=4)
	@Then("Verify that User must see {string} in dropdown")
	public void verify_From_dropdown(String dropdown_value) throws IOException {
		String Text=m.click_spectrum_Internet.getText();
		UIManager.assertEqual(dropdown_value, Text, "Verify dropdown_value is displayed ");

	}
	
	@Test(priority=3)
	@When("User Hover over on Internet Tab and click on Spectrum Internet in dropdown")
	public void click_fromdropdown() throws IOException {
	mgr.waitUntilVisible(m.Internet_tab);	
	mgr.hover(m.Internet_tab);
	mgr.waitUntilVisible(m.click_spectrum_Internet);
	mgr.click(m.click_spectrum_Internet);
	
	}
	
	@Test(priority=3)
	@When("User scroll down to shopultra")
	public void scroll() throws IOException {
		JavascriptExecutor js = (JavascriptExecutor) mgr.driver;
		js.executeScript("arguments[0].scrollIntoView(false)", m.shop_ultra);
		m.shop_ultra.click();
	//mgr.scroll(m.shop_ultra);
	
	}
	
	@Test(priority=3)
	@And("Click on Shopultra")
	public void scrolldown() throws IOException {
		
	System.out.print("asad");
	
	}
	
	@Test(priority=3)
	@And("Click on GetOffer")
	public void Click_getoffer() throws IOException {
		mgr.click(m.Get_Offer);

	
	}

	@Test
	@And("User enter {string}in address field")
	public void Enter_Address(String Text) throws IOException, InterruptedException {
		Thread.sleep(5000);
		mgr.waitUntilVisible(m.enter_address);
		mgr.fillTextField(m.enter_address, Text);
	
	}
	
	@Test
	@Then("Verify that Text field must be filled by address")
	public void Enter_adress() throws IOException {
		Assert.assertNotNull(m.enter_address);
		

	}
	
	@Test
	@And("User enter {string}in Apt unit field")
	public void Enter_Apt_unit(String Text) throws IOException, InterruptedException {
		Thread.sleep(5000);
		mgr.waitUntilVisible(m.app_unit);
		mgr.fillTextField(m.app_unit, Text);
	
	}
	
	@Test
	@Then("Verify that Text field must be filled by Apt")
	public void Verify_Field_notNull() throws IOException {
		
		Assert.assertNotNull(m.app_unit);
		

	}
	
	@Test
	@And("User enter {string}in zipcode field")
	public void Enter_zipcode(String Text) throws IOException, InterruptedException {
		Thread.sleep(5000);
		mgr.waitUntilVisible(m.zipcode);
		mgr.fillTextField(m.zipcode, Text);
	
	}
	
	@Test
	@Then("Verify that Text field must be filled by zipcode")
	public void Verify_Fields_notNull() throws IOException {
		
		Assert.assertNotNull(m.zipcode);
		

	}
	
	@And("click on Find Offers button")
	public void click_on_Find_Offers_button() throws InterruptedException
	{
		Thread.sleep(5000);
		mgr.waitUntilVisible(m.Find_Offers_button);
		mgr.click(m.Find_Offers_button);
	}
	
	@And("scroll down page")
	public void scroll_down_page() throws InterruptedException
	{
		Thread.sleep(5000);
		mgr.scroll(m.Find_Offers_button);
	}
	
	@And("Verify that out of foot print page")
	public void Verify_that_out_of_foot_print_page()
	{
		UIManager.assertTrue(m.verify_address_page.isDisplayed(), "verification check");
	}
	
	@Then("navigate back to previous page")
	public void navigate_back_to_previous_page()
	{
		mgr.navigateTo("https://www.spectrum.com/internet");
	}
	
	@And("scroll down home page")
	public void scroll_down_home_page()
	{
		mgr.waitUntilVisible(m.shop_GIG_Button);
		mgr.scroll(m.shop_GIG_Button, false);
	}
	
	@And("click on shop GIG button")
	public void click_on_shop_GIG_button()
	{
		mgr.click(m.shop_GIG_Button);
	}
	
	@And("Verify localization page")
	public void Verify_localization_page()
	{
		UIManager.assertTrue(m.verify_localization_page.isDisplayed(), "verfication check");
	}

}
