package com.vta.ui.steps.mobile;

import java.io.IOException;

import org.testng.annotations.Test;

import com.charter.enumerations.BrowserType;
import com.charter.web.UIManager;
import com.vta.ui.models.mobile.MobileModule;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MobileSteps {
	
	UIManager mgr = new UIManager(BrowserType.FF32);
	MobileModule m = new MobileModule(mgr.driver);
	
	@Test
	@When("User navigate to {string}")
	public void navigate_To_URL(String url) throws IOException {

	mgr.startSession(url);
	
	
	}
	
	@Test
	@When("Maximixe the window")
	public void Maximixw_window() throws IOException {

	
	mgr.driver.manage().window().maximize();
	
	}
	
	@Test
	@Then("Verify that the title of page should be {string}")
	public void Verify_Title(String Title){
		String actual_Title=mgr.getTitle();
		UIManager.assertEqual(actual_Title, Title, "Verify title is matched or not");
		
		
	}
	
	@Test
	@Then("Close the Browser")
	public void Close_Browser() throws IOException {
		mgr.endSession();

	}
	
	@Test
	@And("User Hover over on Mobile Tab")
	public void Hover_MobileTab() throws IOException {
		
	mgr.waitUntilVisible(m.Hover_Mobile_Tab);
	mgr.hover(m.Hover_Mobile_Tab);
	mgr.waitUntilVisible(m.click_spectrum_Mobile);
	
	}
	
	@Test
	@Then("Verify that User must see {string} in dropdown")
	public void verify_dropdown_value(String dropdown_value) throws IOException {
		String Text=m.click_spectrum_Mobile.getText();
		UIManager.assertEqual(dropdown_value, Text, "Verify dropdown_value is displayed ");

	}
	
	
	@Test
	@And("User Hover over on Mobile Tab and Click on Spectrum Mobile")
	public void Click() throws IOException {
		mgr.waitUntilVisible(m.Hover_Mobile_Tab);
		mgr.hover(m.Hover_Mobile_Tab);
		mgr.waitUntilVisible(m.click_spectrum_Mobile);
		mgr.click(m.click_spectrum_Mobile);
		
		//mgr.hoverAndClick(m.Hover_Mobile_Tab, m.click_spectrum_Mobile);
	
	}
	
	@Test
	@Then("Verify that the URL of the page should be {string}")
	public void Verify_URL(String URL) {
		String actual_URL=mgr.getURL();
		UIManager.assertEqual(actual_URL, URL, "Verify URL is matched or not");
		
	    
	}
	
	@Test
	@And("User Hover over on Products Tab")
	public void Hover_Products_tab() throws IOException {
		
	mgr.waitUntilVisible(m.Hover_over_product);
	mgr.hover(m.Hover_over_product);
	mgr.waitUntilVisible(m.Select_phones);
	
	}
	
	@Test
	@Then("Verify that User should see {string} in dropdown")
	public void verify_dropdowns_value(String dropdown_value) throws IOException {
		String Text=m.Select_phones.getText();
		UIManager.assertEqual(dropdown_value, Text, "Verify dropdown_value is displayed ");

	}
	
	@Test
	@And("User Hover over on Products Tab and Click on Phones")
	public void Hover_Plus_click() throws IOException {
		mgr.waitUntilVisible(m.Hover_over_product);
		mgr.hover(m.Hover_over_product);
		mgr.waitUntilVisible(m.Select_phones);
		mgr.click(m.Select_phones);
		
		//mgr.hoverAndClick(m.Hover_over_product, m.Select_phones);
	
	}
	
	@Test
	@And("Click on Motorola Tab")
	public void Click_MotorolaTab() throws IOException {
		
		mgr.click(m.motorola_tab);
		
	}
	

	@Test
	@And("Click on Google Tab")
	public void Click_GoogleTab() throws IOException {
		
		mgr.click(m.Google_tab);
		
	}
	
	@Test
	@And("Click on samsung Tab")
	public void Click_samsungTab() throws IOException {
		
		mgr.click(m.samsung_tab);
		
	}
	
	@Test
	@And("Click on Deals Tab")
	public void Click_DealsTab() throws IOException {
		
		mgr.click(m.Deals_tab);
		
	}
	
	@Test
	@And("Scroll down to dropdown and click on it")
	public void Scroll_to_dropdown() throws IOException, InterruptedException {
		
		mgr.click(m.Dropdown);
		
	}
	@Test
	@And("Select {string} from dropdown")
	public void selevt_dropdown(String Text) throws InterruptedException {
		mgr.click(m.price_low_tohigh);
		
	}
	
	@Test
	@And("Select {string} from dropdowns")
	public void select_dropdown(String Text) throws InterruptedException {
		mgr.click(m.Featured);
		
	}
	
	@Test
	@And("Selects {string} from dropdown")
	public void selects_dropdown(String Text) throws InterruptedException {
		mgr.click(m.price_high_Low);
		
	}
	
	@Test
	@Then("Verify that User will see {string} in dropdown")
	public void verify_dropdown(String dropdown_value) throws IOException, InterruptedException {
		Thread.sleep(7000);
		String Text=m.Dropdown.getText();
		UIManager.assertEqual(dropdown_value, Text, "Verify dropdown_value is selected or not ");

	}
	
	
	
	@Test
	@And("User clicks on Apple Tab")
	public void Click_AppleTab() throws IOException {
		
		mgr.click(m.iphone_tab);
		
	}
	
	@Test
	@And("Scroll down to Iphone 14 promax and click on it")
	public void Click_14promax() throws IOException, InterruptedException {
		mgr.waitUntilVisible(m.Deals_tab);
		mgr.scroll(m.iphone_14_promax,false);
		mgr.click(m.iphone_14_promax);
		
	}
	
	@Test
	@And("Click on Gold color")
	public void Click_color() throws InterruptedException {
		mgr.click(m.select_iphone_colcor);
	}
	
	@Test
	@And("Click on 128GB storage")
	public void Select_storage() throws InterruptedException {
		mgr.click(m.select_storage);
		
	}
	
	@Test
	@And("Click on single Iphone picture")
	public void Select_Iphonepicture() throws InterruptedException {
		mgr.click(m.choose_second_picture);
		
	}
	@Test
	@And("Click on Payment option")
	public void Select_payment_option() throws InterruptedException {
		mgr.click(m.when_ship);
		
	}
	@Test
	@And("Click on Add protection plan")
	public void Select_protectionplan() throws InterruptedException {
		mgr.click(m.protection_plan);
		
	}
	@Test
	@And("Clik on Trade_In")
	public void Select_Trade_In() throws InterruptedException {
		mgr.click(m.Add_TradeIn);
		
	}
	
	@Test
	@And("Click on AT&T option from Carrier")
	public void Click_on_ATT() throws InterruptedException {
		mgr.click(m.select_ATT);
	}
	@Test
	@And("Click on Apple from Make")
	public void Click_on_Apple_from_Make() throws InterruptedException {
		mgr.click(m.select_apple);
		
	}
	@Test
	@And("Search for Model in Model Tab")
	public void Search_for_Model_in_Model_Tab() throws InterruptedException {
		mgr.click(m.inputfield);
		mgr.click(m.select_fromdropdown);
		
	}
	@Test
	@And("Click on 64GB storage")
	public void Click_on_64GB_storage() throws InterruptedException {
		mgr.click(m.storage);
		
	}
	
	@Test
	@Then("Verify that the {string} button should be enabled")
	public void Verify_Continue_Button_enability(String text) throws InterruptedException {
		Thread.sleep(4000);
		UIManager.assertTrue(m.click_continue.isEnabled(),"Verify Continue Button is enabled or not");
	    
	}
	@Test
	@And("User Click on Continue Button")
	public void Click_on_continue_button() throws InterruptedException {
		mgr.click(m.click_continue);
		
	}
	
	@Test
	@Then("Verify that the system must demand IMEI number from user")
	public void Verify_IMEI_number() {
		UIManager.assertTrue(m.imei_Number.isDisplayed(),"Verify IMEI number is diplayed");
	    
	}
	@Test
	@And("User enter IMEI number {string} in field")
	public void Enter_IMEI(String text) throws InterruptedException {
		mgr.fillTextField(m.imei_Number, text);
	}
	
	@Test
	@Then("Verify that the system must Open device condition page")
	public void Verify_mobile_conditionpage() throws InterruptedException {
		Thread.sleep(4000);
		UIManager.assertTrue(m.click_yes.isDisplayed(),"Verify Mobile condition page will open or not");
	    
	}
	
	@Test
	@And("User put all information about physical condition of Mobile")
	public void Enter_Mobile_condition_details() throws InterruptedException {
		mgr.click(m.click_yes);
		mgr.click(m.second_yes);
		mgr.click(m.third_yes);
		mgr.click(m.fourth_yes);
	}
	
	@Test
	@And("Scroll down to Continue Button and click on it")
	public void Scroll_To_Click() throws InterruptedException {
		mgr.waitUntilVisible(m.show_less);
		mgr.scroll(m.press_continue, false);
		mgr.waitUntilVisible(m.press_continue);
		mgr.click(m.press_continue);
	}
	
	@Test
	@And("Click on Noshop Internet Button")
	public void Click_Noshop_Internet_Button() throws InterruptedException {
		mgr.click(m.shop_internet);
		
	}

}
