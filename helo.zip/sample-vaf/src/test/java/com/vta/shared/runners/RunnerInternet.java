package com.vta.shared.runners;

import org.junit.runner.RunWith;
import org.testng.annotations.Test;

import io.cucumber.junit.CucumberOptions;
import io.cucumber.junit.Cucumber;
@RunWith(Cucumber.class)
@CucumberOptions(
		features="src/test/resources/Features/UI/Internet",
		glue={"com.vta.ui.steps.internet"},
		monochrome=true,
		plugin = {"json:target/cucumber.json"}
)

public class RunnerInternet {

	

}
