package com.vaf.utils;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellUtil;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.util.*;
import java.io.File;
import java.io.FileInputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;

public class dataDriven {

	//Identify Testcases coloum by scanning the entire 1st row
	//once coloumn is identified then scan entire testcase coloum to identify purcjhase testcase row
	//after you grab purchase testcase row = pull all the data of that row and feed into test
	private static String LOCATOR_FILE_PATH = "locators_datasheet.xlsx";
	private static String MOCK_FILE_PATH = "mock_datashee.xls";

	public static ArrayList<String> getLocatorFor(String compoundKey) {
		String sheetName = compoundKey.split("[.]")[0];
		String key = compoundKey.split("[.]")[1];

		try {
			File file;
			try {
				file = getFileFromURL(LOCATOR_FILE_PATH);
			} catch (Exception e) {
				System.out.println("File not found: " + e.getMessage());
				return null;
			}

			FileInputStream fis = new FileInputStream(file);
			Workbook wb;
			if (LOCATOR_FILE_PATH.toLowerCase().endsWith(".xlsx")) {
				wb = new XSSFWorkbook(fis);
			} else {
				wb = new HSSFWorkbook(fis);
			}
			Sheet sheet = wb.getSheet(sheetName);

			Iterator<Row> itr = sheet.iterator();

			ArrayList<String> locatorValues = new ArrayList<>();

			while (itr.hasNext()) {
				Row row = itr.next();
				Iterator<Cell> cellIterator = row.cellIterator();

				String locatorName = "";
				String locatorValue = "";
				String Textvalue = "";

				while (cellIterator.hasNext()) {
					Cell cell = cellIterator.next();

					if (cell.getColumnIndex() == 0) {
						locatorName = cell.getStringCellValue();
					} else if (cell.getColumnIndex() == 1) {
						locatorValue = cell.getStringCellValue();
					}else if (cell.getColumnIndex() == 3) {
						if (cell.getCellType() == CellType.STRING) {
							Textvalue = cell.getStringCellValue();
						} else if (cell.getCellType() == CellType.NUMERIC) {
							double numericValue = cell.getNumericCellValue();
							Textvalue = String.valueOf(numericValue);
						}
					}
				}

				if (locatorName.equals(key)) {
					locatorValues.add(locatorName);
					locatorValues.add(locatorValue);
					locatorValues.add(Textvalue);
					return locatorValues;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	private static File getFileFromURL(String filePath) throws URISyntaxException {
		URL url = new ExcelUtil().getClass().getClassLoader().getResource(filePath);
		File file = null;
		file = new File(url.toURI());
		return file;
	}
}