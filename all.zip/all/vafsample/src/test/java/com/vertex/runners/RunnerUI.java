package com.vertex.runners;

import com.vaf.BaseRunner;
import org.junit.runner.RunWith;

import io.cucumber.junit.CucumberOptions;
import io.cucumber.junit.Cucumber;
@RunWith(Cucumber.class)
@CucumberOptions(
        tags = "@Spectrum_ToolBox_HomePage",
        features="src/test/resources/Features.UI",
        glue={"com.vaf.steps"},
        monochrome=true,
        plugin = {"json:target/cucumber.json"}
)

public class RunnerUI extends BaseRunner {

}
