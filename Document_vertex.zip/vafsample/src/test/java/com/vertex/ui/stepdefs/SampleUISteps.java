package com.vertex.ui.stepdefs;

import com.vaf.enumerations.BrowserType;
import com.vaf.web.UIManager;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import com.vertex.ui.models.SampleUIModel;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;

public class SampleUISteps {
    UIManager mgr = new UIManager(BrowserType.CHROME);
    SampleUIModel m = new SampleUIModel(mgr.driver);

    @Test(priority = 0)
    @When("I navigate {string}")
    public void I_navigate(String url) {

        mgr.startSession(url);
        mgr.maximizeBrowser();
    }

    @When("click on espanol link")
    public void click_on_espanol_link() throws IOException {

        mgr.click(m.espanol_link);

    }

	@Then("Verify that url of the page must be {string}")
	public void verify_url(String title) throws IOException {
		String actual_url=mgr.getURL();
		Assert.assertEquals(title, actual_url, "Verify title is matched ");

	}

    @Test(priority=1)
    @Then("Close the Browser")
    public void Browser() throws IOException {
        mgr.endSession();

    }
}
