package vaf.Steps;
import com.charter.enumerations.BrowserType;
import com.charter.web.UIManager;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.testng.annotations.Test;
import vaf.Pojo.poj;

import java.io.IOException;

public class step {
	UIManager mgr = new UIManager(BrowserType.CHROME32);
	poj m = new poj(mgr.driver);

    @Test
	@When("User navigate to {string}")
	public void navigate_To_URL(String url) throws IOException {

	mgr.startSession(url);


	}

	@Test
	@When("Maximize the window")
	public void Maximize_window() throws IOException {


	mgr.maximizeBrowser();

	}

	@Test
	@Then("Verify that the title of page should be {string}")
	public void Verify_Title(String Title){
		String actual_Title=mgr.getTitle();
		UIManager.assertEqual(actual_Title, Title, "Verify title is matched or not");


	}

	@Test
	@Then("Close the Browser")
	public void Close_Browser() throws IOException {
		mgr.endSession();

	}

	@Test
	@And("User Hover over on Mobile Tab")
	public void Hover_MobileTab() throws IOException {

	mgr.waitUntilVisible(m.Hover_Mobile_Tab);
	mgr.hover(m.Hover_Mobile_Tab);
	mgr.waitUntilVisible(m.click_spectrum_Mobile);

	}

	@Test
	@Then("Verify that User must see {string} in dropdown")
	public void verify_dropdown_value(String dropdown_value) throws IOException {
		String Text=m.click_spectrum_Mobile.getText();
		UIManager.assertEqual(dropdown_value, Text, "Verify dropdown_value is displayed ");

	}


	@Test
	@And("User Hover over on Mobile Tab and Click on Spectrum Mobile")
	public void Click() throws IOException {
		mgr.waitUntilVisible(m.Hover_Mobile_Tab);
		mgr.hover(m.Hover_Mobile_Tab);
		mgr.waitUntilVisible(m.click_spectrum_Mobile);
		mgr.click(m.click_spectrum_Mobile);

		//mgr.hoverAndClick(m.Hover_Mobile_Tab, m.click_spectrum_Mobile);

	}

	@Test
	@Then("Verify that the URL of the page should be {string}")
	public void Verify_URL(String URL) {
		String actual_URL=mgr.getURL();
		UIManager.assertEqual(actual_URL, URL, "Verify URL is matched or not");


	}

	@Test
	@And("User Hover over on Products Tab")
	public void Hover_Products_tab() throws IOException {

	mgr.waitUntilVisible(m.Hover_over_product);
	mgr.hover(m.Hover_over_product);
	mgr.waitUntilVisible(m.Select_phones);

	}

	@Test
	@Then("Verify that User should see {string} in dropdown")
	public void verify_dropdowns_value(String dropdown_value) throws IOException {
		String Text=m.Select_phones.getText();
		UIManager.assertEqual(dropdown_value, Text, "Verify dropdown_value is displayed ");

	}

	@Test
	@And("User Hover over on Products Tab and Click on Phones")
	public void Hover_Plus_click() throws IOException {
		mgr.waitUntilVisible(m.Hover_over_product);
		mgr.hover(m.Hover_over_product);
		mgr.waitUntilVisible(m.Select_phones);
		mgr.click(m.Select_phones);

		//mgr.hoverAndClick(m.Hover_over_product, m.Select_phones);

	}
}
