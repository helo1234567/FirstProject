package vaf.Runner;

import com.charter.BaseRunner;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(



        tags = { "@Spectrum_Mobile_Tab" },
        features = { "src/test/resources/UI" },
        glue = { "vaf.Steps" })
public class Run extends BaseRunner {


}
