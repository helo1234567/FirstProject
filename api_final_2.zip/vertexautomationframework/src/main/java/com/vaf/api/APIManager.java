package com.vaf.api;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import com.vaf.utils.Excel_Api;
import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.path.json.JsonPath;
import org.apache.http.HttpStatus;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hamcrest.Matchers;
import org.hamcrest.core.Is;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


public class APIManager {


    public Response PostRequest(String key1, String key2, String key3, String key4) throws IOException {
        RestAssured.baseURI = "https://rahulshettyacademy.com";
        JSONObject headerJson = new JSONObject(key3);
        Map<String, String> headers = new HashMap<>();

        // Extract key-value pairs from the JSON object and store them in the HashMap
        Iterator<String> keys = headerJson.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            String value = headerJson.getString(key);
            headers.put(key, value);
        }

        Response response = given().queryParam(key2)
                .headers(headers)
                .body(key1)
                .when()
                .post(key4)
                .then()
                .log().all()
                .assertThat()
                .statusCode(200)
                .extract()
                .response();

        JSONObject responseJson = new JSONObject(response.getBody().asString());
        String placeId = responseJson.getString("place_id");
        updatePlaceIdInExcel("C:\\Users\\DELL\\Documents\\api\\demodata.xlsx", "testdata", 3, 1, placeId);
        return response;


    }


    public Response GetRequest(String key1, String key2, String key3, String key4) {
        RestAssured.baseURI = "https://rahulshettyacademy.com";

        Response response = given()
                .queryParam(key2,key1)
                .queryParam("key",key3)
                .when()
                .get(key4)
                .then()
                .log().all()
                .assertThat()
                .statusCode(200)
                .extract()
                .response();

        return response;
    }

//    public Response PutRequest(String key1, String key2, String key3, String key4) {
//        RestAssured.baseURI = "https://rahulshettyacademy.com";
//
//
//
//        Response response = given().
//                queryParam("key", "qaclick123").
//                header("Content-Type", "application/json")
//                .body("{\r\n"
//                        + "\"place_id\":\"" + placeid + "\",\r\n"
//                        + "\"address\":\"" + newadreess + "\",\r\n"
//                        + "\"key\":\"qaclick123\"\r\n"
//                        + "}")
//                .when()
//                .put("/maps/api/place/update/json")
//                .then().log().all().assertThat().statusCode(200)
//                .extract()
//                .response()
//                .asString();
//        return response;
//    }


    public void updatePlaceIdInExcel(String excelFilePath, String sheetName, int cellRowNum, int cellColNum, String placeId) throws IOException {
        FileInputStream fis = new FileInputStream(new File(excelFilePath));
        Workbook workbook = new XSSFWorkbook(fis);
        Sheet sheet = workbook.getSheet(sheetName);

        // Get the specified cell and parse the JSON string
        Row row = sheet.getRow(cellRowNum);
        Cell cell = row.getCell(cellColNum, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
        cell.setCellType(CellType.STRING);
        String jsonCellData = cell.getStringCellValue();

        // Parse the JSON string into a JSONObject
        JSONObject jsonObject = new JSONObject(jsonCellData);

        // Update the place ID value in the JSONObject
        jsonObject.put("place_id", placeId);

        // Update the cell value with the modified JSON string
        cell.setCellValue(jsonObject.toString());

        fis.close();

        FileOutputStream fos = new FileOutputStream(new File(excelFilePath));
        workbook.write(fos);
        workbook.close();
        fos.close();
    }
}
