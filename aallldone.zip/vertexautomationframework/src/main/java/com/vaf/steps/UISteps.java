package com.vaf.steps;

import static org.junit.Assert.assertEquals;


import java.time.Duration;

import java.util.List;
import java.util.Map;

import com.vaf.utils.ExcelUtil;
import cucumber.api.java.en.And;
import cucumber.api.java.en.When;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import org.testng.annotations.Test;
import cucumber.api.java.en.Then;
import com.vaf.web.*;
import com.vaf.web.UIManager.LocatorType;

public class UISteps {


	static UIManager mgr;


	@Test
	@When("User navigate to {string}")
	public void navigate_To_URL(String url) {
		mgr = new UIManager();
		mgr.startSession(url);
	}

	@Test
	@When("Maximize the window")
	public void Maximize_window() {
		mgr.maximizeBrowser();
	}

	@Test
	@Then("Close the Browser")
	public void Close_Browser() {

		mgr.endSession();
		mgr = null;
	}

	@Test
	@And("User Hover over on {string}")
	public void Hover_Over(String key) {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		mgr.hover(value, type);
	}


	@And("User Hover over on {string} and Click on {string}")
	public void Hover_and_click(String key1, String key2) {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key1);
		Map<String, Object> locatorMap1 = ExcelUtil.getLocatorFor(key2);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		String value1 = (String) locatorMap1.get("value");
		LocatorType type1 = (LocatorType) locatorMap1.get("type");
		mgr.hoverAndClick(value, value1, type,type1);
	}

	@Test
	@And("User Click on {string}")
	public void Click(String key) {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		mgr.click(value, type);
	}

	@Test
	@And("Scroll to {string}")
	public void Scroll_to_dropdown(String key) {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		mgr.scroll(value,type,false);

	}

	@Test
	@And("Select {string} from {string}")
	public void select_dropdown(String key1, String key2) {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key1);
		Map<String, Object> locatorMap1 = ExcelUtil.getLocatorFor(key2);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		String value1 = (String) locatorMap1.get("value");
		LocatorType type1 = (LocatorType) locatorMap1.get("type");
		mgr.selectDropdownOption(value1, value, type,type1);

	}


	@Test
	@Then("User Scroll to {string} and Click on {string}")
	public void Scroll_and_click(String key1, String key2) {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key1);
		Map<String, Object> locatorMap1 = ExcelUtil.getLocatorFor(key2);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		String value1 = (String) locatorMap1.get("value");
		LocatorType type1 = (LocatorType) locatorMap1.get("type");
		mgr.scroll_and_Click(value, value1, type,type1);

	}

	@Test
	@And("wait for {string}")
	public void Wait_For_Specific_condition(String key) {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		mgr.waitUntilVisible(value, type);

	}

	@Test
	@And("User will wait for {string}")
	public void Wait(String key){

		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		WebDriverWait wait=new WebDriverWait(mgr.driver, Duration.ofSeconds(40));
		WebElement we=mgr.elementBy(type,value);
		wait.until(ExpectedConditions.visibilityOf(we));

	}


	@Test
	@And("Enter Text in {string} Field")
	public void Enter_Text(String key) throws InterruptedException {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		String text = (String) locatorMap.get("Text");
		mgr.fillTextField(value,text,type);

	}

	@Test
	@And("User Navigate Back")
	public void Navigate_Back() {

		mgr.navigateBack();

	}
	@Test
	@And("User Navigate Forward")
	public void User_Navigate_Forward()  {

		mgr.navigateForward();

	}

	@Test
	@And("Take screenshot")
	public void User_Take_screenshot ()  {

		mgr.logScreenshot();

	}
	@Test
	@And("User Log {string}")
	public void User_Log_Information(String key) {

		mgr.logInfo(key);

	}

	@Test
	@And("Minimize the window")
	public void Minimize_window()  {

		mgr.minimizeBrowser();

	}

	@Test
	@Then("User gets all data from {string} and {string}")
	public void User_gets_all_data_from_excel(String usernameKey, String passwordKey) throws InterruptedException {
		List<String> usernames = ExcelUtil.valuesFor(usernameKey);
		List<String> passwords = ExcelUtil.valuesFor(passwordKey);
		for (int i = 0; i < usernames.size(); i++) {
			String username = usernames.get(i);
			String password = passwords.get(i);
			System.out.println(username);
		}
	}

	@Test
	@And("User shift From current window to Index <{int}> window")
	public void User_shift_to_New_window(Integer key) throws InterruptedException {
	mgr.switchToTab(key);

	}

	@Test
	@And("close new window")
	public void close_new_window()  {
		mgr.driver.close();

	}
	@Test
	@And("User move into Frame {string}")
	public void User_move_into_Frame(String key)  {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		mgr.switchToFrame(value,type);
	}

	@Test
	@And("User move back to Default Frame")
	public void User_move_back_to_Default_Frame() {
	mgr.switchToOutOfFrame();

	}

	@Test
	@And("Enter {string} in {string} Field")
	public void Enter_Texts(String key,String key1) throws InterruptedException {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key1);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		String text = (String) locatorMap.get("Text");
		mgr.fillTextField(value,key,type);

	}

	@Test
	@And("Enter <{int}> in {string} Field")
	public void Enter_Integer(Integer key,String key1) throws InterruptedException {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key1);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		String text = (String) locatorMap.get("Text");
		String Texts= String.valueOf(key);
		mgr.fillTextField(value,Texts,type);

	}

	@Test
	@And("User wait for <{int}> Mili seconds")
	public void User_wait_for(Integer key) throws InterruptedException {
		Thread.sleep(key);

	}

}






