
package com.vaf.utils;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.File;
import java.util.Base64;

public class LogUtil {
	public static ExtentTest extentReportHandler = ExtentCucumberAdapter.getCurrentStep();
	private static final Logger LOGGER = LoggerFactory.getLogger("VAF_LOGGER");

	private static String constructMessage(String msg){
		return "VAF LOG: " + msg;
	}
	public LogUtil() {
		//statics only
	}

	public static void logError(String message) {
		if (ConfigUtil.CONFIG_GET_STRING("EnableReportPortal", ConfigUtil.ConfigType.UIConfig).equals("true")) {
			LOGGER.error( constructMessage(message) );
		}
	}
	public static void logWarning(String message) {
		if (ConfigUtil.CONFIG_GET_STRING("EnableReportPortal", ConfigUtil.ConfigType.UIConfig).equals("true")) {
			LOGGER.warn( constructMessage(message) );
		}
	}
	public static void logInfo(String message) {
		if (ConfigUtil.CONFIG_GET_STRING("EnableReportPortal", ConfigUtil.ConfigType.UIConfig).equals("true")) {
			LOGGER.info( constructMessage(message) );
		}

		if (ConfigUtil.CONFIG_GET_STRING("EnableExtentReport", ConfigUtil.ConfigType.UIConfig).equals("true")) {
			extentReportHandler.info( constructMessage(message) );
		}
	}
	
	public static void logInfo(File file, String message) {
		LOGGER.info("RP_MESSAGE#FILE#{}#{}", file.getAbsolutePath(), message);
	}

	public static void logInfo(byte[] bytes, String message) {
		LOGGER.info("RP_MESSAGE#BASE64#{}#{}", Base64.getEncoder().encodeToString(bytes), message);
	}

	public static void logInfo(String base64, String message) {
		if (ConfigUtil.CONFIG_GET_STRING("EnableReportPortal", ConfigUtil.ConfigType.UIConfig).equals("true")) {
			LOGGER.info("RP_MESSAGE#BASE64#{}#{}", base64, message);
		}
		if (ConfigUtil.CONFIG_GET_STRING("EnableExtentReport", ConfigUtil.ConfigType.UIConfig).equals("true")) {
			extentReportHandler.info(message,
					MediaEntityBuilder.createScreenCaptureFromBase64String(base64).build());

		}

	}

}
